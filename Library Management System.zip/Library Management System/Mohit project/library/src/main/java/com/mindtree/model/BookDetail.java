package com.mindtree.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="BOOK_RESERVATION")
public class BookDetail {
	
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	private int reservationId;
	
	
	@Column(name="BOOK_ID")
	private int bookId;
	@Column(name="VISITOR_ID")
	private int visitorId;
	@Column(name="RESERVATION_DATE")
	@Temporal(TemporalType.DATE)
	private Date reservationDate;
	
	@Column(name="EXPIRATION_DATE")
	@Temporal(TemporalType.DATE)
	private Date expirationDate;

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public int getVisitorId() {
		return visitorId;
	}

	public void setVisitorId(int visitorId) {
		this.visitorId = visitorId;
	}

	public Date getReservationDate() {
		return reservationDate;
	}

	public void setReservationDate(Date reservationDate) {
		this.reservationDate = reservationDate;
	}

	public Date getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	public int getReservationId() {
		return reservationId;
	}

	public void setReservationId(int reservationId) {
		this.reservationId = reservationId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + bookId;
		result = prime * result + ((expirationDate == null) ? 0 : expirationDate.hashCode());
		result = prime * result + ((reservationDate == null) ? 0 : reservationDate.hashCode());
		result = prime * result + reservationId;
		result = prime * result + visitorId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BookDetail other = (BookDetail) obj;
		if (bookId != other.bookId)
			return false;
		if (expirationDate == null) {
			if (other.expirationDate != null)
				return false;
		} else if (!expirationDate.equals(other.expirationDate))
			return false;
		if (reservationDate == null) {
			if (other.reservationDate != null)
				return false;
		} else if (!reservationDate.equals(other.reservationDate))
			return false;
		if (reservationId != other.reservationId)
			return false;
		if (visitorId != other.visitorId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "BookDetail [reservationId=" + reservationId + ", bookId=" + bookId + ", visitorId=" + visitorId
				+ ", reservationDate=" + reservationDate + ", expirationDate=" + expirationDate + "]";
	}

	
	
	

}
