package com.mindtree.dao;

public class AbstractDao {

}
