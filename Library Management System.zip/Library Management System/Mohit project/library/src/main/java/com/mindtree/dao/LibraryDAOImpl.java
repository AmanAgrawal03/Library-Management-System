package com.mindtree.dao;



import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mindtree.model.Book;
import com.mindtree.model.BookDetail;


@Repository("libraryDao")
public class LibraryDAOImpl implements LibraryDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	
	public void addBook(Book book) {
		System.out.println(book.getTitle());
	try{
		Session session=	sessionFactory.openSession();
		Transaction t=session.beginTransaction();
		session.persist(book);
		t.commit();
	
	session.close();
	}catch(Exception e){
		e.printStackTrace();
		
	}
	
		
	}


	public boolean isBookExist(Book book) {
		Session session=	sessionFactory.openSession();
		Transaction t=session.beginTransaction();
		Query query = session.createQuery("select b from Book b where b.title='"+book.getTitle()+"'");
		List result= query.list();
		System.out.println("result is "+ result.size()+ result);
		if(result.size()>0){
			return true;
		}
		return false;
	}


	public Book findById(long id) {
		Session session=	sessionFactory.openSession();
		Transaction t=session.beginTransaction();
		Query query = session.createQuery("select b from Book b where b.id="+id);
		List<Book> result = query.list();
		if(result.size()>0){
		for(Book b :result){
			return b;
		}
		}
		return null;
	}


	public void deleteBookById(long id) {
		Session session=	sessionFactory.openSession();
		Transaction t=session.beginTransaction();
		Query query = session.createQuery("Delete from Book b where b.id="+id);
		query.executeUpdate();
		t.commit();
		session.close();
	}


	public void deleteAllBooks() {
		Session session=	sessionFactory.openSession();
		Transaction t=session.beginTransaction();
		Query query = session.createQuery("Delete from Book ");
		query.executeUpdate();
		t.commit();
		session.close();
		
	}


	public List<Book> findAllBooks() {
		Session session=	sessionFactory.openSession();
		Transaction t=session.beginTransaction();
		Query query = session.createQuery("select b  from Book b");
	List<Book> books =	query.list();
		return books;
	}


	public void reserveBook(BookDetail bookDetail) {
		Session session=	sessionFactory.openSession();
		Transaction t=session.beginTransaction();
		session.persist(bookDetail);
		t.commit();
		
	}


	public List<String> getByUserDate(String date) {
		Session session=	sessionFactory.openSession();
		Transaction t=session.beginTransaction();
		Query query = session.createQuery("select br.bookId from BookDetail br where  br.reservationDate='"+date+"'");
		List<Integer> id = query.list();
		List<String> bookList= new ArrayList<String>();
		for(Integer i:id){
			System.out.println(i);
			query=session.createQuery("select b.title from Book b where  b.id="+i);
			String book =(String) query.uniqueResult();
			bookList.add(book);
		}
		
		return bookList;
	}


	public List<String> getByExpiryDate(String userDate) {
		Session session=	sessionFactory.openSession();
		Transaction t=session.beginTransaction();
		Query query = session.createQuery("select br.bookId from BookDetail br where  br.expirationDate='"+userDate+"'");
		List<Integer> id = query.list();
		List<String> bookList= new ArrayList<String>();
		for(Integer i:id){
			System.out.println(i);
			query=session.createQuery("select b.title from Book b where  b.id="+i);
			String book =(String) query.uniqueResult();
			bookList.add(book);
		}
		
		return bookList;
	}


	public List<String> getByExpiryDate(String expiryDate1, String expiryDate2) {
		Session session=	sessionFactory.openSession();
		Transaction t=session.beginTransaction();
		Query query = session.createQuery("select br.bookId from BookDetail br where  br.expirationDate >'"+expiryDate1+"' and br.expirationDate <'"+ expiryDate2+"'");
		List<Integer> id = query.list();
		List<String> bookList= new ArrayList<String>();
		for(Integer i:id){
			System.out.println(i);
			query=session.createQuery("select b.title from Book b where  b.id="+i);
			String book =(String) query.uniqueResult();
			bookList.add(book);
		}
		
		return bookList;
	}


	public List<String> getByUserDate(String userDate1, String userDate2) {
		Session session=	sessionFactory.openSession();
		Transaction t=session.beginTransaction();
		Query query = session.createQuery("select br.bookId from BookDetail br where  br.reservationDate>'"+userDate1+"' and br.reservationDate<'"+userDate2+"'");
		List<Integer> id = query.list();
		List<String> bookList= new ArrayList<String>();
		for(Integer i:id){
			System.out.println(i);
			query=session.createQuery("select b.title from Book b where  b.id="+i);
			String book =(String) query.uniqueResult();
			bookList.add(book);
		}
		
		return bookList;
	}




}
