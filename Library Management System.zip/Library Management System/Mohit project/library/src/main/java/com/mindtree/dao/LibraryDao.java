package com.mindtree.dao;

import java.util.Date;
import java.util.List;

import com.mindtree.model.Book;
import com.mindtree.model.BookDetail;

public interface LibraryDao {

	void addBook(Book book);

	boolean isBookExist(Book book);

	Book findById(long id);

	void deleteBookById(long id);

	void deleteAllBooks();

	List<Book> findAllBooks();

	void reserveBook(BookDetail bookDetail);

	List<String> getByUserDate(String date);

	List<String> getByExpiryDate(String userDate);

	List<String> getByExpiryDate(String expiryDate1, String expiryDate2);

	List<String> getByUserDate(String userDate1, String userDate2);

}
