package com.mindtree.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mindtree.model.Book;
import com.mindtree.model.BookDetail;
import com.mindtree.service.UserService;

@Controller
@RequestMapping("/")
public class IndexController {

	@Autowired
	UserService userService;

	@RequestMapping(method = RequestMethod.GET)
	public ModelAndView getIndexPage(Model model) {
		List<Book> books = userService.findAllBooks();
		return new ModelAndView("LibraryManagement", "books", books);
	}

	@RequestMapping(value = "/reserveBook", method = RequestMethod.POST)
	public ModelAndView getReservePage(@ModelAttribute("bookDetail") BookDetail bookDetail,
			@ModelAttribute("book") Book book, HttpServletRequest request) {
		String[] id = book.getTitle().split(":");

		String n = id[1];

		int i = Integer.parseInt(n);
		bookDetail.setBookId(i);

		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
		String s = sdf.format(date);
		
		try {
			
			bookDetail.setReservationDate(sdf.parse(s));

			Calendar c = Calendar.getInstance();
			c.setTime(bookDetail.getReservationDate());// starts with today's
														// date and time
			c.add(Calendar.DAY_OF_YEAR, 7); // advances day by 2
			date = c.getTime();

			bookDetail.setExpirationDate(date);

			userService.reserveBook(bookDetail);

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ModelAndView("reserveBook" ,"msg","Your Book is Reserved Successfully");
	}

	@RequestMapping(value = "/showBooks", method = RequestMethod.GET)
	public ModelAndView getByDate(Model model, @RequestParam("value") Integer value) {
		System.out.println(value);

		switch (value) {
		case 1:
			return new ModelAndView("retrieveBook", "id", 1);

		case 2:

			return new ModelAndView("retrieveBook", "id", 2);
		case 3:

			return new ModelAndView("retrieveBook", "id", 3);
		case 4:

			return new ModelAndView("retrieveBook", "id", 4);
		default:
			break;
		}

        return null;
	}

	@RequestMapping(value = "/getByUserRangeDate", method = RequestMethod.POST)
	public ModelAndView getByRange(HttpServletRequest request) {
		String date1 = request.getParameter("userDate1");
		String date2 = request.getParameter("userDate2");
		List<String> books= userService.getByUserRangeDate(date1, date2);
        if(books!=null&& books.size()!=0){
		return new ModelAndView("reserveBook", "books", books);}
        else{
        return new ModelAndView("reserveBook", "msg", "No Book is reserved");}
	}
	
	@RequestMapping(value = "/getByUserDate", method = RequestMethod.POST)
	public ModelAndView getByUserDate(HttpServletRequest request) {
		
		String date = request.getParameter("userDate");
		List<String> books= userService.getByUserDate(date);

		if(books!=null&& books.size()!=0){
			return new ModelAndView("reserveBook", "books", books);}
		else{
	        return new ModelAndView("reserveBook", "msg", "No Book is reserved");}
	}
	
	
	

	@RequestMapping(value = "/getByExpiryDate", method = RequestMethod.POST)
	public ModelAndView getByExpiryDate(HttpServletRequest request) {
		String date = request.getParameter("userDate");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date d = sdf.parse(date);
			date = sdf.format(d);
			
			

			List<String> books = userService.getByUserDate(date);

			if(books!=null&& books.size()!=0){
				return new ModelAndView("reserveBook", "books", books);}
			else{
		        return new ModelAndView("reserveBook", "msg", "No Book is reserved");}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;

	}

	@RequestMapping(value = "/getByExpiryRangeDate", method = RequestMethod.POST)
	public ModelAndView getByRangeDate(HttpServletRequest request) {
		String date1 = request.getParameter("userDate1");
		String date2 = request.getParameter("userDate2");
		List<String> books= userService.getByExpiryDate(date1, date2);

		if(books!=null&& books.size()!=0){
			return new ModelAndView("reserveBook", "books", books);}
		else{
	        return new ModelAndView("reserveBook", "msg", "No Book is reserved");}
	}

}