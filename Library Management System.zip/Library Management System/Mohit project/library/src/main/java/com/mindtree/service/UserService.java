package com.mindtree.service;

import java.util.Date;
import java.util.List;

import com.mindtree.model.Book;
import com.mindtree.model.BookDetail;

public interface UserService {

	public void addBook(Book book) ;

	public boolean isBookExist(Book book);

	public Book findById(long id);

	public void deleteBookById(long id);

	public void deleteAllBooks();

	public List<Book> findAllBooks();

	public void reserveBook(BookDetail bookDetail);

	public List<String> getByUserDate(String date);

	public List<String> getByExpiryDate(String userDate);

	public List<String> getByExpiryDate(String expiryDate1, String expiryDate2);

	public List<String> getByUserRangeDate(String userDate1, String userDate2);

}
