package com.mindtree.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.dao.LibraryDao;
import com.mindtree.model.Book;
import com.mindtree.model.BookDetail;


@Service("userService")
@Transactional
public class UserServiceImpl implements UserService {

	
	@Autowired
	LibraryDao libraryDao;
	
	
	
	public void addBook(Book book) {
		libraryDao.addBook(book);
		
	}



	public boolean isBookExist(Book book) {
		// TODO Auto-generated method stub
		return libraryDao.isBookExist(book);
	}



	public Book findById(long id) {
		// TODO Auto-generated method stub
		return libraryDao.findById(id);
	}



	public void deleteBookById(long id) {
	 libraryDao.deleteBookById(id);
		
	}



	public void deleteAllBooks() {
		libraryDao.deleteAllBooks();
		
	}



	public List<Book> findAllBooks() {
		// TODO Auto-generated method stub
		return libraryDao.findAllBooks();
	}



	public void reserveBook(BookDetail bookDetail) {
		libraryDao.reserveBook(bookDetail);
		
	}



	public List<String> getByUserDate(String date) {
		// TODO Auto-generated method stub
		return libraryDao.getByUserDate(date);
	}



	public List<String> getByExpiryDate(String userDate) {
		// TODO Auto-generated method stub
		return libraryDao.getByExpiryDate(userDate);
	}



	public List<String> getByExpiryDate(String expiryDate1, String expiryDate2) {
		// TODO Auto-generated method stub
		return libraryDao.getByExpiryDate(expiryDate1,expiryDate2);
	}



	public List<String> getByUserRangeDate(String userDate1, String userDate2) {
		// TODO Auto-generated method stub
		return libraryDao.getByUserDate(userDate1,userDate2);
	}
	
	

}
