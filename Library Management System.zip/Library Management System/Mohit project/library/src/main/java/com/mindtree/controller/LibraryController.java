package com.mindtree.controller;


import java.util.List;

import javax.ws.rs.QueryParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.mindtree.model.Book;
import com.mindtree.service.UserService;





@RestController
public class LibraryController {
	
	 @Autowired
	    UserService userService; 
	
	@RequestMapping(value = "/book/", method = RequestMethod.POST)
    public ResponseEntity<Void> addBook(@RequestBody Book book,    UriComponentsBuilder ucBuilder) {
        System.out.println("Adding Book " + book.getTitle());
 
        if (userService.isBookExist(book)) {
            System.out.println("A Book with name " + book.getTitle() + " already exist");
            return new ResponseEntity<Void>(HttpStatus.CONFLICT);
        }
 
        userService.addBook(book);
 
        HttpHeaders headers = new HttpHeaders();
       headers.setLocation(ucBuilder.path("/user/{id}").buildAndExpand(book.getId()).toUri());
        return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
    }
	
	 @RequestMapping(value = "/book/{id}", method = RequestMethod.DELETE)
	    public ResponseEntity<Book> deleteUser(@PathVariable("id") long id) {
	        System.out.println("Fetching & Deleting Book with id " + id);
	 
	        Book book = userService.findById(id);
	        if (book == null) {
	            System.out.println("Unable to delete. Book with id " + id + " not found");
	            return new ResponseEntity<Book>(HttpStatus.NOT_FOUND);
	        }
	 
	        userService.deleteBookById(id);
	        return new ResponseEntity<Book>(HttpStatus.ACCEPTED);
	    }
	 
	     
	    
	    //------------------- Delete All Users --------------------------------------------------------
	     
	    @RequestMapping(value = "/book/", method = RequestMethod.DELETE)
	    public ResponseEntity<Book> deleteAllUsers() {
	        System.out.println("Deleting All Books");
	 
	        userService.deleteAllBooks();
	        return new ResponseEntity<Book>(HttpStatus.NO_CONTENT);
	    }
	    
	    
	    @RequestMapping(value = "/book/", method = RequestMethod.GET)
	    public ResponseEntity<List<Book>> listAllUsers() {
	        List<Book> books = userService.findAllBooks();
	        if(books.isEmpty()){
	            return new ResponseEntity<List<Book>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
	        }
	        return new ResponseEntity<List<Book>>(books, HttpStatus.OK);
	    }
	
	    
	    @RequestMapping(value = "/book", method = RequestMethod.GET)
	    public ResponseEntity<List<String>> listAllBooks(@QueryParam("userDate") String userDate) {
	        List<String> books = userService.getByUserDate(userDate);
	        if(books.isEmpty()){
	            return new ResponseEntity<List<String>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
	        }
	        return new ResponseEntity<List<String>>(books, HttpStatus.OK);
	    }
	    
	    @RequestMapping(value = "/expirybook/", method = RequestMethod.GET)
	    public ResponseEntity<List<String>> listAllBooksByExpiryDate(@QueryParam("expiryDate") String expiryDate) {
	        List<String> books = userService.getByExpiryDate(expiryDate);
	        if(books.isEmpty()){
	            return new ResponseEntity<List<String>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
	        }
	        return new ResponseEntity<List<String>>(books, HttpStatus.OK);
	    }
	    
	    @RequestMapping(value = "/reservebook", method = RequestMethod.GET)
	    public ResponseEntity<List<String>> listAllBooksByUserRangeDate(@QueryParam("userDate1") String userDate1,@QueryParam("userDate2") String userDate2 ) {
	        List<String> books = userService.getByUserRangeDate(userDate1,userDate2);
	        if(books.isEmpty()){
	            return new ResponseEntity<List<String>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
	        }
	        return new ResponseEntity<List<String>>(books, HttpStatus.OK);
	    }
	    
	    @RequestMapping(value = "/expirybook", method = RequestMethod.GET)
	    public ResponseEntity<List<String>> listAllBooksByExpiryRangeDate(@QueryParam("expiryDate1") String expiryDate1,@QueryParam("expiryDate2") String expiryDate2) {
	        List<String> books = userService.getByExpiryDate(expiryDate1,expiryDate2);
	        if(books.isEmpty()){
	            return new ResponseEntity<List<String>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
	        }
	        return new ResponseEntity<List<String>>(books, HttpStatus.OK);
	    }
	    
	    
	    
	    
	    
	

}
